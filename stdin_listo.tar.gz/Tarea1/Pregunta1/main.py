#[VERSION 2 Lee linea por linea e imprime resultado]
def comprobar(atributos,tupla1,tupla2):
    resultado=0
    for i in atributos:
        pos_R=atributos_R.index(i)
        pos_S=atributos_S.index(i)
        if tupla1[pos_R]==tupla2[pos_S]:
            resultado+=1
    if resultado==len(atributos):
        return True
    else: return False
cant_at_R = int(input(":").strip())
atributos_R = input(":").strip().split()
cant_tuplas_R = int(input(":").strip())
lista_tuplas_R=[]
for i in range(cant_tuplas_R):
    lista_tuplas_R.append(tuple(input(":").strip().split()))
cant_at_S = int(input(":").strip())
atributos_S = input(":").strip().split()
cant_tuplas_S = int(input(":").strip())
lista_tuplas_S=[]
for i in range(cant_tuplas_S):
    lista_tuplas_S.append(tuple(input(":").strip().split()))
print("********************")
atributos_de_join=list(set(atributos_R)&set(atributos_S))
atributos_en_orden=list(set(atributos_R)|set(atributos_S))
atributos_en_orden.sort()
print(str(len(atributos_en_orden)))
for i in atributos_en_orden:
    print(i+" ",end="")
print("")
respuesta=[]
for tupla_R in lista_tuplas_R:
    for tupla_S in lista_tuplas_S:
        if comprobar(atributos_de_join,tupla_R,tupla_S):
            linea=""
            for x in atributos_en_orden:
                if x in atributos_R:
                    linea=linea+tupla_R[atributos_R.index(x)]+" "
                else:
                    linea=linea+tupla_S[atributos_S.index(x)]+" "
            respuesta.append(linea)
print(str(len(respuesta)))
for r in respuesta:
    print(r)
