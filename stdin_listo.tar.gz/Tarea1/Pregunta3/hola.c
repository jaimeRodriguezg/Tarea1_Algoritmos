#include <stdio.h>
int main(int argc, char *argv[]) {
int x = 0;
char c[20];
int number;
while (x < 7){
	printf("Ingresa un texto\n");
	scanf("%d",&number);
	x = x + 1;
	printf("%d\n",number);
}
return 0;
}
