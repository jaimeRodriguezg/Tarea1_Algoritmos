Instrucciones de compilacion:

1 - Compilar con "make"
2 - Ejecutar con "./ej < nombre_de_texto.txt"
2 - El resultado se mostrara por consola.

Por ejemplo, si se quiere evaluar el txt que viene como ejemplo, el comando a colocar en el terminal seria: 

$ make
$ ./ej < texto.txt
