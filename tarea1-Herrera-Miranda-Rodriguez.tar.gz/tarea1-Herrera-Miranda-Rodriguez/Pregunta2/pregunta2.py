from sys import stdin

def comprobar(atributos,tupla1,tupla2):
    resultado=0
    for i in atributos:
        pos_R=atributos_R.index(i)
        pos_S=atributos_S.index(i)
        if tupla1[pos_R]==tupla2[pos_S]:
            resultado+=1
    if resultado==len(atributos):
        return True
    else: return False
cant_at_R = 2 #corresponde a la cantidad de atributos
atributos_R = ('1' '2')
lista_tuplas_R=[] #se define un arreglo para las tuplas
c = 0
for i in stdin:
    lista_tuplas_R.append(tuple(i.strip().split())) #se lee el contenido de cada tupla
    c += 1
cant_at_S = 2
atributos_S = ('2' '3')
cant_tuplas_S = c
lista_tuplas_S= lista_tuplas_R
atributos_de_join=list(set(atributos_R)&set(atributos_S))
atributos_en_orden=list(set(atributos_R)|set(atributos_S))
atributos_en_orden.sort()
respuesta=[]
for tupla_R in lista_tuplas_R:
    for tupla_S in lista_tuplas_S:
        if comprobar(atributos_de_join,tupla_R,tupla_S):
            linea=""
            for x in atributos_en_orden:
                if x in atributos_R:
                    linea=linea+tupla_R[atributos_R.index(x)]+" "
                else:
                    linea=linea+tupla_S[atributos_S.index(x)]+" "
            respuesta.append(linea+"\n")
lista_final = []
ciclos = 0
aux = respuesta
repeticiones = []
i = 0
auxiliar = []
for uwu in respuesta:
    auxiliar.append((uwu[0],uwu[2],uwu[4]))
for r in aux:
    if i not in repeticiones:
        lol = (r[4],r[0])
        if lol in lista_tuplas_R:
            goku = (r[2],r[4],r[0])
            vegeta = (r[4],r[0],r[2])
            repeticiones.append(auxiliar.index(goku))
            repeticiones.append(auxiliar.index(vegeta))
            ciclos += 1
    i += 1
print(ciclos) #se imprime resultado