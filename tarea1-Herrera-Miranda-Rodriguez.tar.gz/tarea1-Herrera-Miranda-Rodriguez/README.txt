*Las preguntas 1 y 2 están implementadas en python mientras que la tercera está en c++.

*Para la pregunta 1, asumiendo que se abre la terminal dentro de la carpeta respectiva:
Instrucciones:

1 - Ejecutar con "make < nombre_de_texto.txt"
2 - El resultado se mostrara por consola.

Por ejemplo, si se quiere evaluar el txt que viene como ejemplo, el comando a colocar en la terminal seria: make < entrada.txt

*Para la pregunta 2, asumiendo que se abre la terminal dentro de la carpeta respectiva:
Instrucciones:

1 - Ejecutar con "make < nombre_de_texto.txt"
2 - El resultado se mostrara por consola.

Por ejemplo, si se quiere evaluar el txt que viene como ejemplo, el comando a colocar en la terminal seria: make < grafo.txt

*Por temas de orden, dentro de la carpeta de la pregunta 3, se incluye un readme para cada problema, donde se muestra como compilar y ejecutar.
